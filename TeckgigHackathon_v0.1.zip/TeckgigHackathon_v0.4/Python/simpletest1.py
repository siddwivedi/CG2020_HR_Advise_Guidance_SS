def analyze(mytext,pos_file,neg_file):
    import nltk
    from nltk.classify import NaiveBayesClassifier
    pos = []
    post = pos_file
    negt = neg_file
    with open(post) as f:
        for i in f:
            pos.append([format_sentence(i), 'pos'])
    neg = []
    with open(negt) as f:
        for i in f:
            neg.append([format_sentence(i), 'neg'])
    example1 = mytext
    training = pos[:int((.8) * len(pos))] + neg[:int((.8) * len(neg))]
    test = pos[int((.8) * len(pos)):] + neg[int((.8) * len(neg)):]
    classifier = NaiveBayesClassifier.train(training)
    abc= classifier.classify(format_sentence(example1))
    if abc=='neg':
        abc = 'Negative'
    elif abc == 'pos':
        abc= 'Positive'
    return abc

def format_sentence(sent):
    import nltk
    from nltk.classify import NaiveBayesClassifier
    return({word: True for word in nltk.word_tokenize(sent)})
